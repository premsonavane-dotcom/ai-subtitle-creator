const fileInput=document.getElementById('media'), fileTitle=document.getElementById('file-title');
const statusEl=document.getElementById('status'), generate=document.getElementById('generate');
const transcript=document.getElementById('transcript'), preview=document.getElementById('preview');
const previewText=document.getElementById('preview-text'), srtBtn=document.getElementById('srt'), copyBtn=document.getElementById('copy');
let rows=[], srtUrl='';
fileInput.addEventListener('change',()=>{fileTitle.textContent=fileInput.files[0]?.name||'Drop a file here or browse';});
document.querySelectorAll('.style').forEach(btn=>btn.addEventListener('click',()=>{
 document.querySelectorAll('.style').forEach(b=>b.classList.remove('active'));btn.classList.add('active');
 preview.className='preview '+btn.dataset.style;
}));
function fmt(sec){let m=Math.floor(sec/60),s=Math.floor(sec%60);return `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;}
function render(){
 transcript.innerHTML='';
 rows.forEach((r,i)=>{
  const item=document.createElement('div');item.className='caption';
  const time=document.createElement('div');time.className='time';time.textContent=`${fmt(r.start)} – ${fmt(r.end)}`;
  const input=document.createElement('input');input.value=r.text;input.setAttribute('aria-label',`Caption ${i+1}`);
  input.addEventListener('input',()=>{rows[i].text=input.value;previewText.textContent=input.value||'Subtitle preview';});
  item.append(time,input);transcript.append(item);
 });
 document.getElementById('count').textContent=`${rows.length} captions`;
 previewText.textContent=rows[0]?.text||'Your subtitles will appear here';
}
generate.addEventListener('click',async()=>{
 if(!fileInput.files.length){statusEl.textContent='Please choose a video or audio file first.';return;}
 generate.disabled=true;statusEl.textContent='Loading AI and transcribing… The first run may take several minutes.';
 document.getElementById('bar').style.width='25%';
 const form=new FormData();form.append('media',fileInput.files[0]);form.append('language',document.getElementById('language').value);
 try{
  const res=await fetch('/transcribe',{method:'POST',body:form});const data=await res.json();
  if(!res.ok)throw new Error(data.error||'Something went wrong.');
  rows=data.segments;srtUrl=data.srt_url;render();
  document.getElementById('detected').textContent=`Detected: ${data.detected_language} (${Math.round(data.language_probability*100)}%)`;
  statusEl.textContent=`Done! ${rows.length} captions generated. You can edit the text before exporting.`;
  srtBtn.disabled=false;copyBtn.disabled=false;document.getElementById('bar').style.width='100%';
 }catch(e){statusEl.textContent=e.message;document.getElementById('bar').style.width='0%';}
 finally{generate.disabled=false;}
});
srtBtn.addEventListener('click',()=>{
 // Build SRT from edited transcript so edits are included.
 const stamp=n=>{let ms=Math.round(n*1000),h=Math.floor(ms/3600000);ms%=3600000;let m=Math.floor(ms/60000);ms%=60000;let s=Math.floor(ms/1000);ms%=1000;return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')},${String(ms).padStart(3,'0')}`};
 const body=rows.map((r,i)=>`${i+1}\n${stamp(r.start)} --> ${stamp(r.end)}\n${r.text}`).join('\n\n');
 const a=document.createElement('a');a.href=URL.createObjectURL(new Blob(['\ufeff'+body],{type:'text/plain;charset=utf-8'}));a.download='subtitles.srt';a.click();URL.revokeObjectURL(a.href);
});
copyBtn.addEventListener('click',async()=>{await navigator.clipboard.writeText(rows.map(r=>r.text).join('\n'));statusEl.textContent='Transcript copied.';});
