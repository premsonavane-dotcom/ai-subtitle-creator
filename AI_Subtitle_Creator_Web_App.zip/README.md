# Subtitle Creator AI

A beginner-friendly local web app that transcribes audio/video into editable subtitles and exports an `.srt` file. It uses **faster-whisper** locally on your computer. Media is not uploaded to a third-party transcription service.

## What it does
- Accepts MP4, MOV, MKV, WEBM, MP3, WAV, M4A, AAC, FLAC and OGG.
- Auto-detects speech language or lets you choose an Indian language.
- Supports Hindi, Marathi, Bengali, Tamil, Telugu, Gujarati, Kannada, Malayalam, Punjabi, Urdu, Assamese, Odia, Nepali, Sanskrit and English (Whisper model language support varies).
- Lets you edit the transcript and export a timed SRT.
- Includes six subtitle-style previews: Classic, Bold Pop, Highlight, Karaoke, Cinematic and Minimal.

**Important:** Styles are previews, not burned-in video effects. SRT carries subtitle text and timing only. Import the SRT into Premiere Pro, then apply fonts, colours, animation and word highlighting there. Automatic word-by-word karaoke timing is not included in this starter version.

## Windows setup (beginner)
1. Install **Python 3.10 or 3.11 (64-bit)** from https://www.python.org/downloads/ . During setup, tick **Add Python to PATH**.
2. Extract this ZIP to a folder, for example `C:\SubtitleCreatorAI`.
3. Open that folder. Click the address bar in File Explorer, type `cmd`, and press Enter.
4. Run these commands one by one:

```bat
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python app.py
```

5. Open http://127.0.0.1:5000 in Chrome or Edge.
6. Select your video/audio, choose Auto-detect or a language, and click **Generate subtitles**.
7. Edit any incorrect words, then click **Download SRT**.

The first transcription run downloads the Whisper `small` model (roughly 500 MB; size can vary). Keep the terminal window open while using the app. Close it with Ctrl+C when finished.

## Performance settings
Default is CPU + int8 for broad Windows compatibility. For a lower-memory PC, use a smaller model:

```bat
set WHISPER_MODEL=base
python app.py
```

For better accuracy (slower and more memory), use:

```bat
set WHISPER_MODEL=medium
python app.py
```

Model downloads need an internet connection the first time. Later runs can use the downloaded model offline.

## Troubleshooting
- **`py` is not recognized:** reinstall Python and tick Add Python to PATH.
- **Install fails:** use Python 3.10/3.11 64-bit, then repeat the virtual-environment commands.
- **Slow transcription:** use `set WHISPER_MODEL=base` or `tiny`.
- **No speech detected:** check the clip has audible speech and try a supported audio/video format.
- **Hindi/Marathi spelling or names are wrong:** speech recognition is not perfect; edit the transcript before export.
- **Port busy:** close the other app using port 5000, or change the port in the final `app.run` line.

## Privacy
The app runs on localhost. Uploaded media and generated SRT files are stored in `uploads/` and `outputs/` while the app runs. Delete those folders' contents after use if you want to clear local files. The app does not currently include user accounts or automatic cleanup.
