import os, uuid, re
from flask import Flask, render_template, request, jsonify, send_from_directory
from werkzeug.utils import secure_filename
from faster_whisper import WhisperModel

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 500 * 1024 * 1024
UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "uploads")
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "outputs")
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

ALLOWED = {".mp4", ".mov", ".mkv", ".webm", ".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg"}
MODEL_SIZE = os.environ.get("WHISPER_MODEL", "small")
COMPUTE_TYPE = os.environ.get("WHISPER_COMPUTE", "int8")
model = None

def get_model():
    global model
    if model is None:
        model = WhisperModel(MODEL_SIZE, device="cpu", compute_type=COMPUTE_TYPE)
    return model

def stamp(seconds):
    ms = max(0, int(round(seconds * 1000)))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02}:{m:02}:{s:02},{ms:03}"

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/transcribe", methods=["POST"])
def transcribe():
    if "media" not in request.files:
        return jsonify(error="Please select an audio or video file."), 400
    f = request.files["media"]
    ext = os.path.splitext(secure_filename(f.filename))[1].lower()
    if ext not in ALLOWED:
        return jsonify(error="Supported formats: MP4, MOV, MKV, WEBM, MP3, WAV, M4A, AAC, FLAC, OGG."), 400

    job = uuid.uuid4().hex
    path = os.path.join(UPLOAD_DIR, job + ext)
    f.save(path)
    language = request.form.get("language", "auto")
    lang_arg = None if language == "auto" else language
    try:
        whisper = get_model()
        segments, info = whisper.transcribe(path, language=lang_arg, vad_filter=True, beam_size=5)
        rows = []
        for seg in segments:
            txt = re.sub(r"\s+", " ", seg.text).strip()
            if txt:
                rows.append({"start": float(seg.start), "end": float(seg.end), "text": txt})
        if not rows:
            return jsonify(error="No speech detected. Try a clearer audio/video file."), 422
        srt = []
        for i, row in enumerate(rows, 1):
            srt.append(f"{i}\n{stamp(row['start'])} --> {stamp(row['end'])}\n{row['text']}\n")
        outname = job + ".srt"
        with open(os.path.join(OUTPUT_DIR, outname), "w", encoding="utf-8-sig") as out:
            out.write("\n".join(srt))
        return jsonify(
            segments=rows, detected_language=info.language,
            language_probability=round(float(info.language_probability), 3),
            srt_url="/download/" + outname
        )
    except Exception as e:
        return jsonify(error=f"Transcription failed: {str(e)}"), 500
    finally:
        try: os.remove(path)
        except OSError: pass

@app.route("/download/<path:filename>")
def download(filename):
    return send_from_directory(OUTPUT_DIR, filename, as_attachment=True)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
